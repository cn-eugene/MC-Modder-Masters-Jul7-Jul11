/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alex.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.alex.potion.UnluckyMobEffect;
import net.mcreator.alex.AlexMod;

public class AlexModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, AlexMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> UNLUCKY = REGISTRY.register("unlucky", () -> new UnluckyMobEffect());
}