/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alex.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.alex.AlexMod;

public class AlexModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, AlexMod.MODID);
	public static final DeferredHolder<Potion, Potion> ARROWS = REGISTRY.register("arrows", () -> new Potion("arrows", new MobEffectInstance(AlexModMobEffects.UNLUCKY, 3600, 0, false, true)));
}