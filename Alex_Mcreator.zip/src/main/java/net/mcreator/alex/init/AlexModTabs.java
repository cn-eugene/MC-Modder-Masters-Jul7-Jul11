/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alex.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.alex.AlexMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class AlexModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AlexMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AlexModItems.HAMMER.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(AlexModBlocks.AHHHHHHHHHHHHHHHHHHHH.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AlexModItems.YAY_HELMET.get());
			tabData.accept(AlexModItems.YAY_CHESTPLATE.get());
			tabData.accept(AlexModItems.YAY_LEGGINGS.get());
			tabData.accept(AlexModItems.YAY_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AlexModItems.HELLOTIMETODIE_SPAWN_EGG.get());
		}
	}
}