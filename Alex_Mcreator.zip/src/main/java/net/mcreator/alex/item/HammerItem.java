package net.mcreator.alex.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class HammerItem extends SwordItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 101, 4f, 0, 2, TagKey.create(Registries.ITEM, ResourceLocation.parse("alex:hammer_repair_items")));

	public HammerItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 19999f, -3f, properties);
	}
}