package net.mcreator.alvin.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.CreeperRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.CreeperModel;
import net.minecraft.client.animation.definitions.WardenAnimation;

import net.mcreator.alvin.entity.SoldierEntity;

public class SoldierRenderer extends MobRenderer<SoldierEntity, CreeperRenderState, CreeperModel> {
	private SoldierEntity entity = null;

	public SoldierRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelLayers.CREEPER)), 10f);
	}

	@Override
	public CreeperRenderState createRenderState() {
		return new CreeperRenderState();
	}

	@Override
	public void extractRenderState(SoldierEntity entity, CreeperRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(CreeperRenderState state) {
		return ResourceLocation.parse("alvin:textures/entities/creeper.png");
	}

	private static final class AnimatedModel extends CreeperModel {
		private SoldierEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(SoldierEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(CreeperRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animate(entity.animationState0, WardenAnimation.WARDEN_EMERGE, state.ageInTicks, 1f);
			this.animate(entity.animationState1, WardenAnimation.WARDEN_ATTACK, state.ageInTicks, 1f);
			this.animate(entity.animationState2, WardenAnimation.WARDEN_DIG, state.ageInTicks, 1f);
			this.animate(entity.animationState3, WardenAnimation.WARDEN_ROAR, state.ageInTicks, 1f);
			this.animate(entity.animationState4, WardenAnimation.WARDEN_SNIFF, state.ageInTicks, 1f);
			this.animate(entity.animationState5, WardenAnimation.WARDEN_SONIC_BOOM, state.ageInTicks, 1f);
			super.setupAnim(state);
		}
	}
}