/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alvin.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.alvin.item.WardenarmorItem;
import net.mcreator.alvin.item.StupidswordItem;
import net.mcreator.alvin.item.RedstoneswordItem;
import net.mcreator.alvin.item.OmegabownarrowItem;
import net.mcreator.alvin.AlvinMod;

import java.util.function.Function;

public class AlvinModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(AlvinMod.MODID);
	public static final DeferredItem<Item> STUPIDSWORD = register("stupidsword", StupidswordItem::new);
	public static final DeferredItem<Item> REDSTONESWORD = register("redstonesword", RedstoneswordItem::new);
	public static final DeferredItem<Item> WARDENARMOR_HELMET = register("wardenarmor_helmet", WardenarmorItem.Helmet::new);
	public static final DeferredItem<Item> WARDENARMOR_CHESTPLATE = register("wardenarmor_chestplate", WardenarmorItem.Chestplate::new);
	public static final DeferredItem<Item> WARDENARMOR_LEGGINGS = register("wardenarmor_leggings", WardenarmorItem.Leggings::new);
	public static final DeferredItem<Item> WARDENARMOR_BOOTS = register("wardenarmor_boots", WardenarmorItem.Boots::new);
	public static final DeferredItem<Item> OMEGABOWNARROW = register("omegabownarrow", OmegabownarrowItem::new);
	public static final DeferredItem<Item> OMEGANUKE = block(AlvinModBlocks.OMEGANUKE);
	public static final DeferredItem<Item> SOLDIER_SPAWN_EGG = register("soldier_spawn_egg", properties -> new SpawnEggItem(AlvinModEntities.SOLDIER.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}