/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alvin.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.alvin.AlvinMod;

public class AlvinModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, AlvinMod.MODID);
	public static final DeferredHolder<Potion, Potion> FIREPOTION = REGISTRY.register("firepotion", () -> new Potion("firepotion", new MobEffectInstance(AlvinModMobEffects.FIRE, 60, 100, false, false)));
}