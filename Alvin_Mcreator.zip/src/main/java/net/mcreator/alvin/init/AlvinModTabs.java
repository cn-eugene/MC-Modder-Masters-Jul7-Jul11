/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.alvin.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.alvin.AlvinMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class AlvinModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AlvinMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(AlvinModItems.STUPIDSWORD.get());
			tabData.accept(AlvinModItems.REDSTONESWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(AlvinModItems.WARDENARMOR_HELMET.get());
			tabData.accept(AlvinModItems.WARDENARMOR_CHESTPLATE.get());
			tabData.accept(AlvinModItems.WARDENARMOR_LEGGINGS.get());
			tabData.accept(AlvinModItems.WARDENARMOR_BOOTS.get());
			tabData.accept(AlvinModItems.OMEGABOWNARROW.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(AlvinModBlocks.OMEGANUKE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(AlvinModItems.SOLDIER_SPAWN_EGG.get());
		}
	}
}