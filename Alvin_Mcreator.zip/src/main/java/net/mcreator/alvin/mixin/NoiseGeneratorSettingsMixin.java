package net.mcreator.alvin.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.alvin.init.AlvinModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements AlvinModBiomes.AlvinModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> alvin_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.alvin_dimensionTypeReference != null) {
			retval = AlvinModBiomes.adaptSurfaceRule(retval, this.alvin_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setalvinDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.alvin_dimensionTypeReference = dimensionType;
	}
}