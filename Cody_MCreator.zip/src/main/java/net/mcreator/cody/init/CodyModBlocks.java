/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cody.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.cody.block.SUPERTNTBLOCKBlock;
import net.mcreator.cody.block.PineTreeWoodBlockBlock;
import net.mcreator.cody.block.PinePlanksBlock;
import net.mcreator.cody.block.PineForestLeavesBlock;
import net.mcreator.cody.block.PineForestDirtBlockBlock;
import net.mcreator.cody.block.PineForestClayBlock;
import net.mcreator.cody.block.FireBlockBlock;
import net.mcreator.cody.CodyMod;

import java.util.function.Function;

public class CodyModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(CodyMod.MODID);
	public static final DeferredBlock<Block> FIRE_BLOCK = register("fire_block", FireBlockBlock::new);
	public static final DeferredBlock<Block> SUPERTNTBLOCK = register("supertntblock", SUPERTNTBLOCKBlock::new);
	public static final DeferredBlock<Block> PINE_TREE_WOOD_BLOCK = register("pine_tree_wood_block", PineTreeWoodBlockBlock::new);
	public static final DeferredBlock<Block> PINE_FOREST_LEAVES = register("pine_forest_leaves", PineForestLeavesBlock::new);
	public static final DeferredBlock<Block> PINE_FOREST_DIRT_BLOCK = register("pine_forest_dirt_block", PineForestDirtBlockBlock::new);
	public static final DeferredBlock<Block> PINE_FOREST_CLAY = register("pine_forest_clay", PineForestClayBlock::new);
	public static final DeferredBlock<Block> PINE_PLANKS = register("pine_planks", PinePlanksBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			PineTreeWoodBlockBlock.blockColorLoad(event);
		}
	}
}