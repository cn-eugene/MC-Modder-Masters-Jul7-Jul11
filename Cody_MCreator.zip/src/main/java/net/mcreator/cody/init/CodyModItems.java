/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cody.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.cody.item.WardenArmorItem;
import net.mcreator.cody.item.FireSword1Item;
import net.mcreator.cody.item.FirePickaxeItem;
import net.mcreator.cody.item.FireIngotItem;
import net.mcreator.cody.item.FireDiamondItem;
import net.mcreator.cody.CodyMod;

import java.util.function.Function;

public class CodyModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(CodyMod.MODID);
	public static final DeferredItem<Item> FIRE_DIAMOND = register("fire_diamond", FireDiamondItem::new);
	public static final DeferredItem<Item> FIRE_BLOCK = block(CodyModBlocks.FIRE_BLOCK, new Item.Properties().stacksTo(99).rarity(Rarity.EPIC).fireResistant());
	public static final DeferredItem<Item> FIRE_INGOT = register("fire_ingot", FireIngotItem::new);
	public static final DeferredItem<Item> FIRE_SWORD_1 = register("fire_sword_1", FireSword1Item::new);
	public static final DeferredItem<Item> FIRE_PICKAXE = register("fire_pickaxe", FirePickaxeItem::new);
	public static final DeferredItem<Item> SUPERTNTBLOCK = block(CodyModBlocks.SUPERTNTBLOCK, new Item.Properties().rarity(Rarity.EPIC));
	public static final DeferredItem<Item> WARDEN_ARMOR_HELMET = register("warden_armor_helmet", WardenArmorItem.Helmet::new);
	public static final DeferredItem<Item> WARDEN_ARMOR_CHESTPLATE = register("warden_armor_chestplate", WardenArmorItem.Chestplate::new);
	public static final DeferredItem<Item> WARDEN_ARMOR_LEGGINGS = register("warden_armor_leggings", WardenArmorItem.Leggings::new);
	public static final DeferredItem<Item> WARDEN_ARMOR_BOOTS = register("warden_armor_boots", WardenArmorItem.Boots::new);
	public static final DeferredItem<Item> SWAMP_VILLAGER_SPAWN_EGG = register("swamp_villager_spawn_egg", properties -> new SpawnEggItem(CodyModEntities.SWAMP_VILLAGER.get(), properties));
	public static final DeferredItem<Item> PINE_TREE_WOOD_BLOCK = block(CodyModBlocks.PINE_TREE_WOOD_BLOCK);
	public static final DeferredItem<Item> PINE_FOREST_LEAVES = block(CodyModBlocks.PINE_FOREST_LEAVES);
	public static final DeferredItem<Item> PINE_FOREST_DIRT_BLOCK = block(CodyModBlocks.PINE_FOREST_DIRT_BLOCK);
	public static final DeferredItem<Item> PINE_FOREST_CLAY = block(CodyModBlocks.PINE_FOREST_CLAY);
	public static final DeferredItem<Item> PINE_PLANKS = block(CodyModBlocks.PINE_PLANKS);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}