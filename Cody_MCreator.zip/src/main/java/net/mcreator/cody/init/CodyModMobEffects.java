/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cody.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.cody.potion.PotionofarrowsMobEffect;
import net.mcreator.cody.CodyMod;

public class CodyModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, CodyMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> POTIONOFARROWS = REGISTRY.register("potionofarrows", () -> new PotionofarrowsMobEffect());
}