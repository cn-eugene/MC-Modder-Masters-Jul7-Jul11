/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cody.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.cody.CodyMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class CodyModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CodyMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(CodyModItems.FIRE_DIAMOND.get());
			tabData.accept(CodyModItems.FIRE_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(CodyModBlocks.FIRE_BLOCK.get().asItem());
			tabData.accept(CodyModBlocks.PINE_TREE_WOOD_BLOCK.get().asItem());
			tabData.accept(CodyModBlocks.PINE_FOREST_LEAVES.get().asItem());
			tabData.accept(CodyModBlocks.PINE_FOREST_DIRT_BLOCK.get().asItem());
			tabData.accept(CodyModBlocks.PINE_FOREST_CLAY.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(CodyModItems.FIRE_SWORD_1.get());
			tabData.accept(CodyModItems.FIRE_PICKAXE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(CodyModBlocks.SUPERTNTBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(CodyModItems.WARDEN_ARMOR_HELMET.get());
			tabData.accept(CodyModItems.WARDEN_ARMOR_CHESTPLATE.get());
			tabData.accept(CodyModItems.WARDEN_ARMOR_LEGGINGS.get());
			tabData.accept(CodyModItems.WARDEN_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(CodyModItems.SWAMP_VILLAGER_SPAWN_EGG.get());
		}
	}
}