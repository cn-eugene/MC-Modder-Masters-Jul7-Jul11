package net.mcreator.cody.item;

import net.minecraft.world.item.Item;

public class FireIngotItem extends Item {
	public FireIngotItem(Item.Properties properties) {
		super(properties.stacksTo(99).fireResistant());
	}
}