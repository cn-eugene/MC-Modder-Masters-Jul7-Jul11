
package net.mcreator.crosby.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;

public class ImopBlock extends Block {
	public ImopBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(10.05f, 10f).friction(0.01f).jumpFactor(120.4f));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}
