
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.crosby.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.crosby.block.TntmouseBlock;
import net.mcreator.crosby.block.SoooomBlock;
import net.mcreator.crosby.block.ImopBlock;
import net.mcreator.crosby.CrosbyMod;

import java.util.function.Function;

public class CrosbyModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(CrosbyMod.MODID);
	public static final DeferredBlock<Block> SOOOOM = register("soooom", SoooomBlock::new);
	public static final DeferredBlock<Block> TNTMOUSE = register("tntmouse", TntmouseBlock::new);
	public static final DeferredBlock<Block> IMOP = register("imop", ImopBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}
