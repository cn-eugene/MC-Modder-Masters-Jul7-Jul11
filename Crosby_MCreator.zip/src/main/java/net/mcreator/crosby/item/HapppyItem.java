
package net.mcreator.crosby.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.AxeItem;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class HapppyItem extends AxeItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 128000, 11115f, 0, 111112, TagKey.create(Registries.ITEM, ResourceLocation.parse("crosby:happpy_repair_items")));

	public HapppyItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 33f, 26f, properties.fireResistant());
	}
}
