
package net.mcreator.crosby.item;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.LivingEntity;

public class MoooosItem extends Item {
	public MoooosItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC).stacksTo(60).fireResistant().food((new FoodProperties.Builder()).nutrition(400).saturationModifier(300f).alwaysEdible().build()).enchantable(75));
	}

	@Override
	public ItemStack getCraftingRemainder(ItemStack itemstack) {
		return new ItemStack(this);
	}

	@Override
	public int getUseDuration(ItemStack itemstack, LivingEntity livingEntity) {
		return 0;
	}

	@Override
	public float getDestroySpeed(ItemStack itemstack, BlockState state) {
		return 15f;
	}

	@Override
	public boolean isCorrectToolForDrops(ItemStack itemstack, BlockState state) {
		return true;
	}
}
