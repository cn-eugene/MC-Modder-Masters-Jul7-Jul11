
package net.mcreator.crosby.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class WraithofmouseMobEffect extends MobEffect {
	public WraithofmouseMobEffect() {
		super(MobEffectCategory.HARMFUL, -1);
	}
}
