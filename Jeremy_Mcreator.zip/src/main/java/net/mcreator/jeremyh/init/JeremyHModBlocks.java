/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jeremyh.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.jeremyh.block.BloodydimensionPortalBlock;
import net.mcreator.jeremyh.block.BloodtntBlock;
import net.mcreator.jeremyh.block.BlooddimmondblockBlock;
import net.mcreator.jeremyh.JeremyHMod;

import java.util.function.Function;

public class JeremyHModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(JeremyHMod.MODID);
	public static final DeferredBlock<Block> BLOODDIMMONDBLOCK = register("blooddimmondblock", BlooddimmondblockBlock::new);
	public static final DeferredBlock<Block> BLOODTNT = register("bloodtnt", BloodtntBlock::new);
	public static final DeferredBlock<Block> BLOODYDIMENSION_PORTAL = register("bloodydimension_portal", BloodydimensionPortalBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			BlooddimmondblockBlock.blockColorLoad(event);
			BloodtntBlock.blockColorLoad(event);
		}
	}
}