/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jeremyh.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.jeremyh.entity.CutevillagerEntity;
import net.mcreator.jeremyh.entity.BloodyzombieEntity;
import net.mcreator.jeremyh.entity.BloodystevespetEntity;
import net.mcreator.jeremyh.entity.BloodysteveEntity;
import net.mcreator.jeremyh.JeremyHMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JeremyHModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, JeremyHMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<BloodysteveEntity>> BLOODYSTEVE = register("bloodysteve",
			EntityType.Builder.<BloodysteveEntity>of(BloodysteveEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(2010).setUpdateInterval(3).fireImmune().ridingOffset(-0.6f).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<CutevillagerEntity>> CUTEVILLAGER = register("cutevillager",
			EntityType.Builder.<CutevillagerEntity>of(CutevillagerEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(2000).setUpdateInterval(3).fireImmune()

					.sized(0.6f, 1.95f));
	public static final DeferredHolder<EntityType<?>, EntityType<BloodystevespetEntity>> BLOODYSTEVESPET = register("bloodystevespet",
			EntityType.Builder.<BloodystevespetEntity>of(BloodystevespetEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.7f));
	public static final DeferredHolder<EntityType<?>, EntityType<BloodyzombieEntity>> BLOODYZOMBIE = register("bloodyzombie",
			EntityType.Builder.<BloodyzombieEntity>of(BloodyzombieEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(JeremyHMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		BloodysteveEntity.init(event);
		CutevillagerEntity.init(event);
		BloodystevespetEntity.init(event);
		BloodyzombieEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BLOODYSTEVE.get(), BloodysteveEntity.createAttributes().build());
		event.put(CUTEVILLAGER.get(), CutevillagerEntity.createAttributes().build());
		event.put(BLOODYSTEVESPET.get(), BloodystevespetEntity.createAttributes().build());
		event.put(BLOODYZOMBIE.get(), BloodyzombieEntity.createAttributes().build());
	}
}