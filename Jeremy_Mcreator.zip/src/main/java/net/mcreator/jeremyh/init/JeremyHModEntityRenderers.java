/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jeremyh.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.jeremyh.client.renderer.CutevillagerRenderer;
import net.mcreator.jeremyh.client.renderer.BloodyzombieRenderer;
import net.mcreator.jeremyh.client.renderer.BloodystevespetRenderer;
import net.mcreator.jeremyh.client.renderer.BloodysteveRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class JeremyHModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(JeremyHModEntities.BLOODYSTEVE.get(), BloodysteveRenderer::new);
		event.registerEntityRenderer(JeremyHModEntities.CUTEVILLAGER.get(), CutevillagerRenderer::new);
		event.registerEntityRenderer(JeremyHModEntities.BLOODYSTEVESPET.get(), BloodystevespetRenderer::new);
		event.registerEntityRenderer(JeremyHModEntities.BLOODYZOMBIE.get(), BloodyzombieRenderer::new);
	}
}