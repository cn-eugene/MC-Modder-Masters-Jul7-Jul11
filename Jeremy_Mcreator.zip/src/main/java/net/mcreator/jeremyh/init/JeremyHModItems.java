/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jeremyh.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.jeremyh.item.BloodydimensionItem;
import net.mcreator.jeremyh.item.BloodtoolItem;
import net.mcreator.jeremyh.item.BlooddimmondItem;
import net.mcreator.jeremyh.item.BloodarmorItem;
import net.mcreator.jeremyh.JeremyHMod;

import java.util.function.Function;

public class JeremyHModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JeremyHMod.MODID);
	public static final DeferredItem<Item> BLOODDIMMOND = register("blooddimmond", BlooddimmondItem::new);
	public static final DeferredItem<Item> BLOODDIMMONDBLOCK = block(JeremyHModBlocks.BLOODDIMMONDBLOCK, new Item.Properties().stacksTo(99).fireResistant());
	public static final DeferredItem<Item> BLOODTNT = block(JeremyHModBlocks.BLOODTNT, new Item.Properties().stacksTo(99));
	public static final DeferredItem<Item> BLOODTOOL = register("bloodtool", BloodtoolItem::new);
	public static final DeferredItem<Item> BLOODARMOR_HELMET = register("bloodarmor_helmet", BloodarmorItem.Helmet::new);
	public static final DeferredItem<Item> BLOODARMOR_CHESTPLATE = register("bloodarmor_chestplate", BloodarmorItem.Chestplate::new);
	public static final DeferredItem<Item> BLOODARMOR_LEGGINGS = register("bloodarmor_leggings", BloodarmorItem.Leggings::new);
	public static final DeferredItem<Item> BLOODARMOR_BOOTS = register("bloodarmor_boots", BloodarmorItem.Boots::new);
	public static final DeferredItem<Item> BLOODYSTEVE_SPAWN_EGG = register("bloodysteve_spawn_egg", properties -> new SpawnEggItem(JeremyHModEntities.BLOODYSTEVE.get(), properties));
	public static final DeferredItem<Item> CUTEVILLAGER_SPAWN_EGG = register("cutevillager_spawn_egg", properties -> new SpawnEggItem(JeremyHModEntities.CUTEVILLAGER.get(), properties));
	public static final DeferredItem<Item> BLOODYSTEVESPET_SPAWN_EGG = register("bloodystevespet_spawn_egg", properties -> new SpawnEggItem(JeremyHModEntities.BLOODYSTEVESPET.get(), properties));
	public static final DeferredItem<Item> BLOODYZOMBIE_SPAWN_EGG = register("bloodyzombie_spawn_egg", properties -> new SpawnEggItem(JeremyHModEntities.BLOODYZOMBIE.get(), properties));
	public static final DeferredItem<Item> BLOODYDIMENSION = register("bloodydimension", BloodydimensionItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}