/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jeremyh.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.jeremyh.JeremyHMod;

public class JeremyHModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, JeremyHMod.MODID);
	public static final DeferredHolder<Potion, Potion> BLOODITEM = REGISTRY.register("blooditem",
			() -> new Potion("blooditem", new MobEffectInstance(MobEffects.REGENERATION, 3600, 0, false, false), new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 3600, 0, false, false),
					new MobEffectInstance(MobEffects.SLOW_FALLING, 3600, 0, false, false), new MobEffectInstance(MobEffects.DAMAGE_BOOST, 3600, 0, false, false), new MobEffectInstance(MobEffects.WATER_BREATHING, 3600, 0, false, false),
					new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 3600, 0, false, true)));
}