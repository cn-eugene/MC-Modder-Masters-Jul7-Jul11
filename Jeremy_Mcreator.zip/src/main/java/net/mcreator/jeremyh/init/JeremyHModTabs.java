/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.jeremyh.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.jeremyh.JeremyHMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JeremyHModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JeremyHMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JeremyHModItems.BLOODDIMMOND.get());
			tabData.accept(JeremyHModItems.BLOODARMOR_HELMET.get());
			tabData.accept(JeremyHModItems.BLOODARMOR_CHESTPLATE.get());
			tabData.accept(JeremyHModItems.BLOODARMOR_LEGGINGS.get());
			tabData.accept(JeremyHModItems.BLOODARMOR_BOOTS.get());
			tabData.accept(JeremyHModItems.BLOODYSTEVE_SPAWN_EGG.get());
			tabData.accept(JeremyHModItems.CUTEVILLAGER_SPAWN_EGG.get());
			tabData.accept(JeremyHModItems.BLOODYDIMENSION.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(JeremyHModBlocks.BLOODDIMMONDBLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(JeremyHModBlocks.BLOODTNT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JeremyHModItems.BLOODTOOL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JeremyHModItems.BLOODYSTEVE_SPAWN_EGG.get());
			tabData.accept(JeremyHModItems.CUTEVILLAGER_SPAWN_EGG.get());
			tabData.accept(JeremyHModItems.BLOODYSTEVESPET_SPAWN_EGG.get());
			tabData.accept(JeremyHModItems.BLOODYZOMBIE_SPAWN_EGG.get());
		}
	}
}