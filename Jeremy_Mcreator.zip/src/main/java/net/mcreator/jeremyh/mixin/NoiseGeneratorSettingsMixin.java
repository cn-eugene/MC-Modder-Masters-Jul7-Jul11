package net.mcreator.jeremyh.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.jeremyh.init.JeremyHModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements JeremyHModBiomes.JeremyHModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> jeremy_h_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.jeremy_h_dimensionTypeReference != null) {
			retval = JeremyHModBiomes.adaptSurfaceRule(retval, this.jeremy_h_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setjeremy_hDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.jeremy_h_dimensionTypeReference = dimensionType;
	}
}