/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.john.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.john.item.ZSwordItem;
import net.mcreator.john.item.TwoStarDragonBallItem;
import net.mcreator.john.item.OneStarDragonBallItem;
import net.mcreator.john.item.KiblastttItem;
import net.mcreator.john.item.AssItem;
import net.mcreator.john.item.ArmorArmorItem;
import net.mcreator.john.JohnMod;

import java.util.function.Function;

public class JohnModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JohnMod.MODID);
	public static final DeferredItem<Item> ONE_STAR_DRAGON_BALL = register("one_star_dragon_ball", OneStarDragonBallItem::new);
	public static final DeferredItem<Item> KATCHINTITE = block(JohnModBlocks.KATCHINTITE);
	public static final DeferredItem<Item> TWO_STAR_DRAGON_BALL = register("two_star_dragon_ball", TwoStarDragonBallItem::new);
	public static final DeferredItem<Item> KIBLASTTT = register("kiblasttt", KiblastttItem::new);
	public static final DeferredItem<Item> Z_SWORD = register("z_sword", ZSwordItem::new);
	public static final DeferredItem<Item> PUNISHER = register("punisher", AssItem::new);
	public static final DeferredItem<Item> OMEGATNT = block(JohnModBlocks.OMEGATNT, new Item.Properties().rarity(Rarity.UNCOMMON));
	public static final DeferredItem<Item> ARMOR_ARMOR_HELMET = register("armor_armor_helmet", ArmorArmorItem.Helmet::new);
	public static final DeferredItem<Item> ARMOR_ARMOR_CHESTPLATE = register("armor_armor_chestplate", ArmorArmorItem.Chestplate::new);
	public static final DeferredItem<Item> ARMOR_ARMOR_LEGGINGS = register("armor_armor_leggings", ArmorArmorItem.Leggings::new);
	public static final DeferredItem<Item> ARMOR_ARMOR_BOOTS = register("armor_armor_boots", ArmorArmorItem.Boots::new);
	public static final DeferredItem<Item> SAMUS_SPAWN_EGG = register("samus_spawn_egg", properties -> new SpawnEggItem(JohnModEntities.SAMUS.get(), properties));

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}