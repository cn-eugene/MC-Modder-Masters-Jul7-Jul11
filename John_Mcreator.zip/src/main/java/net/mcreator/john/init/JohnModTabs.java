/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.john.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.john.JohnMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JohnModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JohnMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(JohnModItems.ONE_STAR_DRAGON_BALL.get());
			tabData.accept(JohnModItems.TWO_STAR_DRAGON_BALL.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(JohnModBlocks.KATCHINTITE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JohnModItems.KIBLASTTT.get());
			tabData.accept(JohnModItems.Z_SWORD.get());
			tabData.accept(JohnModItems.PUNISHER.get());
			tabData.accept(JohnModItems.ARMOR_ARMOR_HELMET.get());
			tabData.accept(JohnModItems.ARMOR_ARMOR_CHESTPLATE.get());
			tabData.accept(JohnModItems.ARMOR_ARMOR_LEGGINGS.get());
			tabData.accept(JohnModItems.ARMOR_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JohnModItems.Z_SWORD.get());
			tabData.accept(JohnModItems.PUNISHER.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(JohnModBlocks.OMEGATNT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JohnModItems.SAMUS_SPAWN_EGG.get());
		}
	}
}