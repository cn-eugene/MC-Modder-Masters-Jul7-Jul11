package net.mcreator.john.procedures;

public class KiBlastWhileProjectileFlyingTickProcedure {
	public static void execute() {
	}
}