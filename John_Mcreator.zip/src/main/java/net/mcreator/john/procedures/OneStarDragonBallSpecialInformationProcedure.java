package net.mcreator.john.procedures;

public class OneStarDragonBallSpecialInformationProcedure {
	public static void execute() {
	}
}