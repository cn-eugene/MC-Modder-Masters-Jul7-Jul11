package net.mcreator.josiah.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.FallingBlock;

import com.mojang.serialization.MapCodec;

public class SlipBlock extends FallingBlock {
	public static final MapCodec<SlipBlock> CODEC = simpleCodec(SlipBlock::new);

	public MapCodec<SlipBlock> codec() {
		return CODEC;
	}

	public SlipBlock(BlockBehaviour.Properties properties) {
		super(properties.sound(SoundType.GRAVEL).strength(-1, 3600000).friction(1.12f).speedFactor(100f).jumpFactor(100f));
	}

	@Override
	public int getLightBlock(BlockState state) {
		return 15;
	}
}