/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.josiah.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.josiah.block.TntmpBlock;
import net.mcreator.josiah.block.SlipBlock;
import net.mcreator.josiah.block.SapphireBlock;
import net.mcreator.josiah.block.RichmoneyBlock;
import net.mcreator.josiah.block.AquePortalBlock;
import net.mcreator.josiah.JosiahMod;

import java.util.function.Function;

public class JosiahModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(JosiahMod.MODID);
	public static final DeferredBlock<Block> SAPPHIRE = register("sapphire", SapphireBlock::new);
	public static final DeferredBlock<Block> TNTMP = register("tntmp", TntmpBlock::new);
	public static final DeferredBlock<Block> AQUE_PORTAL = register("aque_portal", AquePortalBlock::new);
	public static final DeferredBlock<Block> RICHMONEY = register("richmoney", RichmoneyBlock::new);
	public static final DeferredBlock<Block> SLIP = register("slip", SlipBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}