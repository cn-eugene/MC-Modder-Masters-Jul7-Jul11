/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.josiah.init;

import org.checkerframework.checker.guieffect.qual.UI;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.josiah.item.UiItem;
import net.mcreator.josiah.item.SporkItem;
import net.mcreator.josiah.item.SkeletonItem;
import net.mcreator.josiah.item.SijiItem;
import net.mcreator.josiah.item.ScythheItem;
import net.mcreator.josiah.item.ScytheItem;
import net.mcreator.josiah.item.SapphireitimItem;
import net.mcreator.josiah.item.RedslashItem;
import net.mcreator.josiah.item.OnixstafItem;
import net.mcreator.josiah.item.OnixItem;
import net.mcreator.josiah.item.JhuiItem;
import net.mcreator.josiah.item.AqueItem;
import net.mcreator.josiah.JosiahMod;

import java.util.function.Function;

public class JosiahModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(JosiahMod.MODID);
	public static final DeferredItem<Item> ONIX = register("onix", OnixItem::new);
	public static final DeferredItem<Item> SAPPHIRE = block(JosiahModBlocks.SAPPHIRE);
	public static final DeferredItem<Item> SAPPHIREITIM = register("sapphireitim", SapphireitimItem::new);
	public static final DeferredItem<Item> SPORK = register("spork", SporkItem::new);
	public static final DeferredItem<Item> UI = register("ui", UiItem::new);
	public static final DeferredItem<Item> JHUI = register("jhui", JhuiItem::new);
	public static final DeferredItem<Item> ONIXSTAF = register("onixstaf", OnixstafItem::new);
	public static final DeferredItem<Item> SKELETON_HELMET = register("skeleton_helmet", SkeletonItem.Helmet::new);
	public static final DeferredItem<Item> SKELETON_CHESTPLATE = register("skeleton_chestplate", SkeletonItem.Chestplate::new);
	public static final DeferredItem<Item> SKELETON_LEGGINGS = register("skeleton_leggings", SkeletonItem.Leggings::new);
	public static final DeferredItem<Item> SKELETON_BOOTS = register("skeleton_boots", SkeletonItem.Boots::new);
	public static final DeferredItem<Item> TNTMP = block(JosiahModBlocks.TNTMP);
	public static final DeferredItem<Item> REDSLASH = register("redslash", RedslashItem::new);
	public static final DeferredItem<Item> SCYTHE = register("scythe", ScytheItem::new);
	public static final DeferredItem<Item> SCYTHHE = register("scythhe", ScythheItem::new);
	public static final DeferredItem<Item> AQUE = register("aque", AqueItem::new);
	public static final DeferredItem<Item> RICHMONEY = block(JosiahModBlocks.RICHMONEY, new Item.Properties().stacksTo(99));
	public static final DeferredItem<Item> SLIP = block(JosiahModBlocks.SLIP, new Item.Properties().fireResistant());
	public static final DeferredItem<Item> ASSASSIN_SPAWN_EGG = register("assassin_spawn_egg", properties -> new SpawnEggItem(JosiahModEntities.ASSASSIN.get(), properties));
	public static final DeferredItem<Item> SIJI = register("siji", SijiItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}