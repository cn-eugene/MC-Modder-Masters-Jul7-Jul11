/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.josiah.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.josiah.potion.WraithofhevenMobEffect;
import net.mcreator.josiah.JosiahMod;

public class JosiahModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, JosiahMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> WRAITHOFHEVEN = REGISTRY.register("wraithofheven", () -> new WraithofhevenMobEffect());
}