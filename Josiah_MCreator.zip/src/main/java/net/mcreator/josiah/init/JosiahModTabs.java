/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.josiah.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.josiah.JosiahMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class JosiahModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, JosiahMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(JosiahModItems.ONIX.get());
			tabData.accept(JosiahModItems.SAPPHIREITIM.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(JosiahModBlocks.SAPPHIRE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(JosiahModItems.SPORK.get());
			tabData.accept(JosiahModItems.UI.get());
			tabData.accept(JosiahModItems.JHUI.get());
			tabData.accept(JosiahModItems.ONIXSTAF.get());
			tabData.accept(JosiahModItems.SCYTHE.get());
			tabData.accept(JosiahModItems.AQUE.get());
			tabData.accept(JosiahModItems.SIJI.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(JosiahModItems.SKELETON_HELMET.get());
			tabData.accept(JosiahModItems.SKELETON_CHESTPLATE.get());
			tabData.accept(JosiahModItems.SKELETON_LEGGINGS.get());
			tabData.accept(JosiahModItems.SKELETON_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(JosiahModBlocks.TNTMP.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COLORED_BLOCKS) {
			tabData.accept(JosiahModBlocks.SLIP.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(JosiahModItems.ASSASSIN_SPAWN_EGG.get());
		}
	}
}