package net.mcreator.josiah.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class OnixItem extends Item {
	public OnixItem(Item.Properties properties) {
		super(properties.rarity(Rarity.EPIC));
	}
}