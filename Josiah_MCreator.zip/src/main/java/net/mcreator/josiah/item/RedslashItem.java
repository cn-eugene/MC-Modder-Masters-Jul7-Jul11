package net.mcreator.josiah.item;

import net.minecraft.world.item.Item;

public class RedslashItem extends Item {
	public RedslashItem(Item.Properties properties) {
		super(properties);
	}
}