package net.mcreator.josiah.item;

import net.minecraft.world.item.Item;

public class SapphireitimItem extends Item {
	public SapphireitimItem(Item.Properties properties) {
		super(properties);
	}
}