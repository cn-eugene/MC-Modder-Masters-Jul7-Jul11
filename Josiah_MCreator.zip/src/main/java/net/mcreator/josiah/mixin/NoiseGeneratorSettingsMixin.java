package net.mcreator.josiah.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.josiah.init.JosiahModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements JosiahModBiomes.JosiahModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> josiah_dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.josiah_dimensionTypeReference != null) {
			retval = JosiahModBiomes.adaptSurfaceRule(retval, this.josiah_dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setjosiahDimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.josiah_dimensionTypeReference = dimensionType;
	}
}