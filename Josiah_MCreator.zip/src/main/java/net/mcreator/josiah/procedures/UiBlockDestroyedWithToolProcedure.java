package net.mcreator.josiah.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.josiah.JosiahMod;

public class UiBlockDestroyedWithToolProcedure {
	public static void execute(LevelAccessor world, double x, double z) {
		double work = 0;
		work = 0;
		for (int index0 = 0; index0 < 319; index0++) {
			work = work + 1;
			JosiahMod.LOGGER.info(work);
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, work, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						"fill ~-7 ~ ~-7 ~8 ~ ~8 air destroy");
		}
	}
}