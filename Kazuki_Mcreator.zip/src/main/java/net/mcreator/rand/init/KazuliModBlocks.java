/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rand.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.rand.block.TsarbombasBlock;
import net.mcreator.rand.block.TableBlock;
import net.mcreator.rand.block.RawsteeloreBlock;
import net.mcreator.rand.block.LaptopBlock;
import net.mcreator.rand.KazuliMod;

import java.util.function.Function;

public class KazuliModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(KazuliMod.MODID);
	public static final DeferredBlock<Block> RAWSTEELORE = register("rawsteelore", RawsteeloreBlock::new);
	public static final DeferredBlock<Block> TSARBOMBAS = register("tsarbombas", TsarbombasBlock::new);
	public static final DeferredBlock<Block> TABLE = register("table", TableBlock::new);
	public static final DeferredBlock<Block> LAPTOP = register("laptop", LaptopBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}