/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rand.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.rand.client.renderer.ChickRenderer;
import net.mcreator.rand.client.renderer.ChairRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class KazuliModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(KazuliModEntities.BULLET.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(KazuliModEntities.BULLET_2.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(KazuliModEntities.CHICK.get(), ChickRenderer::new);
		event.registerEntityRenderer(KazuliModEntities.CHAIR.get(), ChairRenderer::new);
	}
}