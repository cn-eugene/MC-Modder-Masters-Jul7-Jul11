/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rand.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.rand.item.SteelswordItem;
import net.mcreator.rand.item.SteelstuffItem;
import net.mcreator.rand.item.SteelshovItem;
import net.mcreator.rand.item.SteelpickItem;
import net.mcreator.rand.item.SteelhoeItem;
import net.mcreator.rand.item.SteelaxeItem;
import net.mcreator.rand.item.SteelItem;
import net.mcreator.rand.item.HammerItem;
import net.mcreator.rand.item.Glock17Item;
import net.mcreator.rand.item.BulletsItem;
import net.mcreator.rand.item.Bullet3Item;
import net.mcreator.rand.KazuliMod;

import java.util.function.Function;

public class KazuliModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(KazuliMod.MODID);
	public static final DeferredItem<Item> STEEL = register("steel", SteelItem::new);
	public static final DeferredItem<Item> RAWSTEELORE = block(KazuliModBlocks.RAWSTEELORE);
	public static final DeferredItem<Item> STEELSWORD = register("steelsword", SteelswordItem::new);
	public static final DeferredItem<Item> STEELPICK = register("steelpick", SteelpickItem::new);
	public static final DeferredItem<Item> STEELAXE = register("steelaxe", SteelaxeItem::new);
	public static final DeferredItem<Item> STEELSHOV = register("steelshov", SteelshovItem::new);
	public static final DeferredItem<Item> STEELHOE = register("steelhoe", SteelhoeItem::new);
	public static final DeferredItem<Item> TSARBOMBAS = block(KazuliModBlocks.TSARBOMBAS);
	public static final DeferredItem<Item> GLOCK_17 = register("glock_17", Glock17Item::new);
	public static final DeferredItem<Item> STEELSTUFF_HELMET = register("steelstuff_helmet", SteelstuffItem.Helmet::new);
	public static final DeferredItem<Item> STEELSTUFF_CHESTPLATE = register("steelstuff_chestplate", SteelstuffItem.Chestplate::new);
	public static final DeferredItem<Item> STEELSTUFF_LEGGINGS = register("steelstuff_leggings", SteelstuffItem.Leggings::new);
	public static final DeferredItem<Item> STEELSTUFF_BOOTS = register("steelstuff_boots", SteelstuffItem.Boots::new);
	public static final DeferredItem<Item> BULLETS = register("bullets", BulletsItem::new);
	public static final DeferredItem<Item> BULLET_3 = register("bullet_3", Bullet3Item::new);
	public static final DeferredItem<Item> CHICK_SPAWN_EGG = register("chick_spawn_egg", properties -> new SpawnEggItem(KazuliModEntities.CHICK.get(), properties));
	public static final DeferredItem<Item> TABLE = block(KazuliModBlocks.TABLE);
	public static final DeferredItem<Item> CHAIR_SPAWN_EGG = register("chair_spawn_egg", properties -> new SpawnEggItem(KazuliModEntities.CHAIR.get(), properties));
	public static final DeferredItem<Item> LAPTOP = block(KazuliModBlocks.LAPTOP);
	public static final DeferredItem<Item> HAMMER = register("hammer", HammerItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}