/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.rand.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.rand.KazuliMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class KazuliModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, KazuliMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(KazuliModItems.STEEL.get());
			tabData.accept(KazuliModItems.STEELSWORD.get());
			tabData.accept(KazuliModItems.STEELPICK.get());
			tabData.accept(KazuliModItems.STEELAXE.get());
			tabData.accept(KazuliModItems.STEELSHOV.get());
			tabData.accept(KazuliModItems.STEELHOE.get());
			tabData.accept(KazuliModItems.GLOCK_17.get());
			tabData.accept(KazuliModItems.HAMMER.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(KazuliModBlocks.RAWSTEELORE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(KazuliModBlocks.TSARBOMBAS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(KazuliModItems.STEELSTUFF_HELMET.get());
			tabData.accept(KazuliModItems.STEELSTUFF_CHESTPLATE.get());
			tabData.accept(KazuliModItems.STEELSTUFF_LEGGINGS.get());
			tabData.accept(KazuliModItems.STEELSTUFF_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(KazuliModItems.CHICK_SPAWN_EGG.get());
			tabData.accept(KazuliModItems.CHAIR_SPAWN_EGG.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(KazuliModBlocks.TABLE.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
			tabData.accept(KazuliModBlocks.LAPTOP.get().asItem());
		}
	}
}