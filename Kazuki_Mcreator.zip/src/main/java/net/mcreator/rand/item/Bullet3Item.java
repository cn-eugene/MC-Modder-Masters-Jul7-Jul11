package net.mcreator.rand.item;

import net.minecraft.world.item.Item;

public class Bullet3Item extends Item {
	public Bullet3Item(Item.Properties properties) {
		super(properties);
	}
}