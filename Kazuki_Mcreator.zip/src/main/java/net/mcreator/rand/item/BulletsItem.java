package net.mcreator.rand.item;

import net.minecraft.world.item.Item;

public class BulletsItem extends Item {
	public BulletsItem(Item.Properties properties) {
		super(properties);
	}
}