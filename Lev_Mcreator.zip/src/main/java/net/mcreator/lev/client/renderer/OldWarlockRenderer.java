package net.mcreator.lev.client.renderer;

import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.WitchRenderState;
import net.minecraft.client.renderer.entity.state.HoldingEntityRenderState;
import net.minecraft.client.renderer.entity.layers.CrossedArmsItemLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.WitchModel;
import net.minecraft.client.animation.definitions.CreakingAnimation;

import net.mcreator.lev.entity.OldWarlockEntity;

import com.mojang.blaze3d.vertex.PoseStack;

public class OldWarlockRenderer extends MobRenderer<OldWarlockEntity, WitchRenderState, WitchModel> {
	private OldWarlockEntity entity = null;

	public OldWarlockRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(ModelLayers.WITCH)), 0.5f);
		this.addLayer(new CrossedArmsItemLayer<>(this));
	}

	@Override
	public WitchRenderState createRenderState() {
		return new WitchRenderState();
	}

	@Override
	public void extractRenderState(OldWarlockEntity entity, WitchRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
		if (this.model instanceof AnimatedModel) {
			((AnimatedModel) this.model).setEntity(entity);
		}
		if (state instanceof HoldingEntityRenderState holdingState) {
			this.itemModelResolver.updateForLiving(holdingState.heldItem, entity.getMainHandItem(), ItemDisplayContext.GROUND, false, entity);
		}
	}

	@Override
	public ResourceLocation getTextureLocation(WitchRenderState state) {
		return ResourceLocation.parse("lev_:textures/entities/witch.png");
	}

	@Override
	protected void scale(WitchRenderState state, PoseStack poseStack) {
		poseStack.scale(1.1f, 1.1f, 1.1f);
	}

	private static final class AnimatedModel extends WitchModel {
		private OldWarlockEntity entity = null;

		public AnimatedModel(ModelPart root) {
			super(root);
		}

		public void setEntity(OldWarlockEntity entity) {
			this.entity = entity;
		}

		@Override
		public void setupAnim(WitchRenderState state) {
			this.root().getAllParts().forEach(ModelPart::resetPose);
			this.animateWalk(CreakingAnimation.CREAKING_WALK, state.walkAnimationPos, state.walkAnimationSpeed, 2f, 1f);
			super.setupAnim(state);
		}
	}
}