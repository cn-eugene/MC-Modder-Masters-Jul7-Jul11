package net.mcreator.lev.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.lev.init.LevModItems;
import net.mcreator.lev.init.LevModFluids;
import net.mcreator.lev.init.LevModFluidTypes;
import net.mcreator.lev.init.LevModBlocks;

public abstract class BloodFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> LevModFluidTypes.BLOOD_TYPE.get(), () -> LevModFluids.BLOOD.get(), () -> LevModFluids.FLOWING_BLOOD.get()).explosionResistance(100f)
			.bucket(() -> LevModItems.BLOOD_BUCKET.get()).block(() -> (LiquidBlock) LevModBlocks.BLOOD.get());

	private BloodFluid() {
		super(PROPERTIES);
	}

	public static class Source extends BloodFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends BloodFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}