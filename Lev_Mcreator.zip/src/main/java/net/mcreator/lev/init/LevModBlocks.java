/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lev.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.client.event.RegisterColorHandlersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.lev.block.ShadeStoneBlock;
import net.mcreator.lev.block.NecromiumOreBlock;
import net.mcreator.lev.block.MOONgrassBlock;
import net.mcreator.lev.block.HellfirebombBlock;
import net.mcreator.lev.block.DriedWarlockheadBlock;
import net.mcreator.lev.block.BloodyhellPortalBlock;
import net.mcreator.lev.block.BloodStoneBlock;
import net.mcreator.lev.block.BloodBlock;
import net.mcreator.lev.LevMod;

import java.util.function.Function;

public class LevModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(LevMod.MODID);
	public static final DeferredBlock<Block> BLOOD_STONE = register("blood_stone", BloodStoneBlock::new);
	public static final DeferredBlock<Block> BLOOD = register("blood", BloodBlock::new);
	public static final DeferredBlock<Block> BLOODYHELL_PORTAL = register("bloodyhell_portal", BloodyhellPortalBlock::new);
	public static final DeferredBlock<Block> HELLFIREBOMB = register("hellfirebomb", HellfirebombBlock::new);
	public static final DeferredBlock<Block> MOO_NGRASS = register("moo_ngrass", MOONgrassBlock::new);
	public static final DeferredBlock<Block> DRIED_WARLOCKHEAD = register("dried_warlockhead", DriedWarlockheadBlock::new);
	public static final DeferredBlock<Block> SHADE_STONE = register("shade_stone", ShadeStoneBlock::new);
	public static final DeferredBlock<Block> NECROMIUM_ORE = register("necromium_ore", NecromiumOreBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}

	@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			MOONgrassBlock.blockColorLoad(event);
		}
	}
}