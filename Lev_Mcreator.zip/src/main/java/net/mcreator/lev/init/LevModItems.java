/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lev.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.lev.item.UnpolishedbloodkrystleItem;
import net.mcreator.lev.item.UnholywaterItem;
import net.mcreator.lev.item.ShadowmailItem;
import net.mcreator.lev.item.PortalingitItem;
import net.mcreator.lev.item.NecromiumItem;
import net.mcreator.lev.item.LifedrinkerItem;
import net.mcreator.lev.item.HatItem;
import net.mcreator.lev.item.EggyItem;
import net.mcreator.lev.item.BloodyhellItem;
import net.mcreator.lev.item.BloodKrystleItem;
import net.mcreator.lev.item.BloodItem;
import net.mcreator.lev.LevMod;

import java.util.function.Function;

public class LevModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(LevMod.MODID);
	public static final DeferredItem<Item> UNHOLYWATER = register("unholywater", UnholywaterItem::new);
	public static final DeferredItem<Item> BLOOD_KRYSTLE = register("blood_krystle", BloodKrystleItem::new);
	public static final DeferredItem<Item> BLOOD_STONE = block(LevModBlocks.BLOOD_STONE, new Item.Properties().rarity(Rarity.UNCOMMON).fireResistant());
	public static final DeferredItem<Item> LIFEDRINKER = register("lifedrinker", LifedrinkerItem::new);
	public static final DeferredItem<Item> UNPOLISHEDBLOODKRYSTLE = register("unpolishedbloodkrystle", UnpolishedbloodkrystleItem::new);
	public static final DeferredItem<Item> BLOOD_BUCKET = register("blood_bucket", BloodItem::new);
	public static final DeferredItem<Item> BLOODYHELL = register("bloodyhell", BloodyhellItem::new);
	public static final DeferredItem<Item> HELLFIREBOMB = block(LevModBlocks.HELLFIREBOMB);
	public static final DeferredItem<Item> HAT = register("hat", HatItem::new);
	public static final DeferredItem<Item> PORTALINGIT = register("portalingit", PortalingitItem::new);
	public static final DeferredItem<Item> EGGY = register("eggy", EggyItem::new);
	public static final DeferredItem<Item> MOO_NGRASS = block(LevModBlocks.MOO_NGRASS, new Item.Properties().rarity(Rarity.RARE));
	public static final DeferredItem<Item> SHADOWMAIL_HELMET = register("shadowmail_helmet", ShadowmailItem.Helmet::new);
	public static final DeferredItem<Item> SHADOWMAIL_CHESTPLATE = register("shadowmail_chestplate", ShadowmailItem.Chestplate::new);
	public static final DeferredItem<Item> SHADOWMAIL_LEGGINGS = register("shadowmail_leggings", ShadowmailItem.Leggings::new);
	public static final DeferredItem<Item> SHADOWMAIL_BOOTS = register("shadowmail_boots", ShadowmailItem.Boots::new);
	public static final DeferredItem<Item> NECROMIUM = register("necromium", NecromiumItem::new);
	public static final DeferredItem<Item> OLD_WARLOCK_SPAWN_EGG = register("old_warlock_spawn_egg", properties -> new SpawnEggItem(LevModEntities.OLD_WARLOCK.get(), properties));
	public static final DeferredItem<Item> DRIED_WARLOCKHEAD = block(LevModBlocks.DRIED_WARLOCKHEAD);
	public static final DeferredItem<Item> SHADE_STONE = block(LevModBlocks.SHADE_STONE);
	public static final DeferredItem<Item> NECROMIUM_ORE = block(LevModBlocks.NECROMIUM_ORE);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}