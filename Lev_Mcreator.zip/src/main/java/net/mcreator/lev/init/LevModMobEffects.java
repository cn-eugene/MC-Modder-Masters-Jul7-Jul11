/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lev.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.lev.potion.OwwMobEffect;
import net.mcreator.lev.LevMod;

public class LevModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, LevMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> OWW = REGISTRY.register("oww", () -> new OwwMobEffect());
}