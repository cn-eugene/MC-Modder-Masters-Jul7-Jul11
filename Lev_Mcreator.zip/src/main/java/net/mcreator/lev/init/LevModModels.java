/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lev.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.lev.client.model.ModelShadow_Golem;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class LevModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelShadow_Golem.LAYER_LOCATION, ModelShadow_Golem::createBodyLayer);
	}
}