/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lev.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.lev.LevMod;

public class LevModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, LevMod.MODID);
	public static final DeferredHolder<Potion, Potion> FUN_SUPRISE = REGISTRY.register("fun_suprise",
			() -> new Potion("fun_suprise", new MobEffectInstance(LevModMobEffects.OWW, 200, 0, true, true), new MobEffectInstance(MobEffects.GLOWING, 100, 0, true, true)));
}