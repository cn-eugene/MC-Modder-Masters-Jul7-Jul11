/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.lev.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.lev.LevMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class LevModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LevMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MYTAB = REGISTRY.register("mytab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.lev_.mytab")).icon(() -> new ItemStack(LevModItems.LIFEDRINKER.get())).displayItems((parameters, tabData) -> {
				tabData.accept(LevModItems.UNHOLYWATER.get());
				tabData.accept(LevModBlocks.BLOOD_STONE.get().asItem());
				tabData.accept(LevModItems.LIFEDRINKER.get());
				tabData.accept(LevModItems.BLOODYHELL.get());
				tabData.accept(LevModBlocks.HELLFIREBOMB.get().asItem());
				tabData.accept(LevModItems.HAT.get());
				tabData.accept(LevModBlocks.MOO_NGRASS.get().asItem());
				tabData.accept(LevModItems.SHADOWMAIL_HELMET.get());
				tabData.accept(LevModItems.SHADOWMAIL_CHESTPLATE.get());
				tabData.accept(LevModItems.SHADOWMAIL_LEGGINGS.get());
				tabData.accept(LevModItems.SHADOWMAIL_BOOTS.get());
				tabData.accept(LevModItems.OLD_WARLOCK_SPAWN_EGG.get());
				tabData.accept(LevModBlocks.DRIED_WARLOCKHEAD.get().asItem());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(LevModItems.LIFEDRINKER.get());
			tabData.accept(LevModItems.BLOODYHELL.get());
			tabData.accept(LevModItems.EGGY.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(LevModBlocks.HELLFIREBOMB.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(LevModBlocks.MOO_NGRASS.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(LevModItems.SHADOWMAIL_HELMET.get());
			tabData.accept(LevModItems.SHADOWMAIL_CHESTPLATE.get());
			tabData.accept(LevModItems.SHADOWMAIL_LEGGINGS.get());
			tabData.accept(LevModItems.SHADOWMAIL_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(LevModItems.OLD_WARLOCK_SPAWN_EGG.get());
		}
	}
}