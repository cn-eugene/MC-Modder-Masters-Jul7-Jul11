package net.mcreator.lev.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.lev.init.LevModFluids;

public class BloodItem extends BucketItem {
	public BloodItem(Item.Properties properties) {
		super(LevModFluids.BLOOD.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}