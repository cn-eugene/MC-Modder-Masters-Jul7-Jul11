package net.mcreator.lev.item;

import net.minecraft.world.item.Item;

public class BloodKrystleItem extends Item {
	public BloodKrystleItem(Item.Properties properties) {
		super(properties);
	}
}