package net.mcreator.lev.item;

import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.tags.TagKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.lev.procedures.OwwOnEffectActiveTickProcedure;

public class EggyItem extends ShieldItem {
	public EggyItem(Item.Properties properties) {
		super(properties.durability(100).fireResistant().repairable(TagKey.create(Registries.ITEM, ResourceLocation.parse("lev_:eggy_repair_items"))));
	}

	@Override
	public boolean hurtEnemy(ItemStack itemstack, LivingEntity entity, LivingEntity sourceentity) {
		boolean retval = super.hurtEnemy(itemstack, entity, sourceentity);
		OwwOnEffectActiveTickProcedure.execute(entity.level(), entity);
		return retval;
	}
}