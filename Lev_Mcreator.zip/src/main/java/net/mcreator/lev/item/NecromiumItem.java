package net.mcreator.lev.item;

import net.minecraft.world.item.Item;

public class NecromiumItem extends Item {
	public NecromiumItem(Item.Properties properties) {
		super(properties);
	}
}