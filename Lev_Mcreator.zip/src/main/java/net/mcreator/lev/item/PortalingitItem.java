package net.mcreator.lev.item;

import net.minecraft.world.item.Item;

public class PortalingitItem extends Item {
	public PortalingitItem(Item.Properties properties) {
		super(properties);
	}
}