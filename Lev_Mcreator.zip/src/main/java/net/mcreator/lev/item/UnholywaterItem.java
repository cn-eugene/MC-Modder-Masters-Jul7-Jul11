package net.mcreator.lev.item;

import net.minecraft.world.item.component.Consumables;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.lev.LevMod;

public class UnholywaterItem extends Item {
	public UnholywaterItem(Item.Properties properties) {
		super(properties.rarity(Rarity.RARE).stacksTo(20).food((new FoodProperties.Builder()).nutrition(35).saturationModifier(3f).alwaysEdible().build(), Consumables.DEFAULT_DRINK).usingConvertsTo(Items.GLASS_BOTTLE)
				.jukeboxPlayable(ResourceKey.create(Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(LevMod.MODID, "unholywater"))));
	}
}