package net.mcreator.lev.item;

import net.minecraft.world.item.Item;

public class UnpolishedbloodkrystleItem extends Item {
	public UnpolishedbloodkrystleItem(Item.Properties properties) {
		super(properties);
	}
}