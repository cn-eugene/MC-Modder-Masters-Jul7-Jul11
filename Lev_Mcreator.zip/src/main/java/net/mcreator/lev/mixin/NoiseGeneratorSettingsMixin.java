package net.mcreator.lev.mixin;

import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;

import net.minecraft.world.level.levelgen.SurfaceRules;
import net.minecraft.world.level.levelgen.NoiseGeneratorSettings;
import net.minecraft.world.level.dimension.DimensionType;
import net.minecraft.core.Holder;

import net.mcreator.lev.init.LevModBiomes;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;

@Mixin(NoiseGeneratorSettings.class)
public class NoiseGeneratorSettingsMixin implements LevModBiomes.LevModNoiseGeneratorSettings {
	@Unique
	private Holder<DimensionType> lev__dimensionTypeReference;

	@WrapMethod(method = "surfaceRule")
	public SurfaceRules.RuleSource surfaceRule(Operation<SurfaceRules.RuleSource> original) {
		SurfaceRules.RuleSource retval = original.call();
		if (this.lev__dimensionTypeReference != null) {
			retval = LevModBiomes.adaptSurfaceRule(retval, this.lev__dimensionTypeReference);
		}
		return retval;
	}

	@Override
	public void setlev_DimensionTypeReference(Holder<DimensionType> dimensionType) {
		this.lev__dimensionTypeReference = dimensionType;
	}
}