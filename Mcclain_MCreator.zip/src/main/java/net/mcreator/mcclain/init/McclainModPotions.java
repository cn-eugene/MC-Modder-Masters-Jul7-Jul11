/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mcclain.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.mcclain.McclainMod;

public class McclainModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, McclainMod.MODID);
	public static final DeferredHolder<Potion, Potion> POTION = REGISTRY.register("potion", () -> new Potion("potion", new MobEffectInstance(McclainModMobEffects.ARROW, 5000, 0, false, false)));
}