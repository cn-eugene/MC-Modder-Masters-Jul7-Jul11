/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.riley.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.riley.block.RnvmbfBlock;
import net.mcreator.riley.block.RerBlock;
import net.mcreator.riley.block.HhgmBlock;
import net.mcreator.riley.block.FggjBlock;
import net.mcreator.riley.RileyMod;

import java.util.function.Function;

public class RileyModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(RileyMod.MODID);
	public static final DeferredBlock<Block> RER = register("rer", RerBlock::new);
	public static final DeferredBlock<Block> RNVMBF = register("rnvmbf", RnvmbfBlock::new);
	public static final DeferredBlock<Block> FGGJ = register("fggj", FggjBlock::new);
	public static final DeferredBlock<Block> HHGM = register("hhgm", HhgmBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}