/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.riley.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.riley.item.RubyItem;
import net.mcreator.riley.item.RtItem;
import net.mcreator.riley.item.OmegaSwordItem;
import net.mcreator.riley.item.OmegaItem;
import net.mcreator.riley.item.OmegaBowItem;
import net.mcreator.riley.RileyMod;

import java.util.function.Function;

public class RileyModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(RileyMod.MODID);
	public static final DeferredItem<Item> RUBY = register("ruby", RubyItem::new);
	public static final DeferredItem<Item> OMEGA_SWORD = register("omega_sword", OmegaSwordItem::new);
	public static final DeferredItem<Item> OMEGA_HELMET = register("omega_helmet", OmegaItem.Helmet::new);
	public static final DeferredItem<Item> OMEGA_CHESTPLATE = register("omega_chestplate", OmegaItem.Chestplate::new);
	public static final DeferredItem<Item> OMEGA_LEGGINGS = register("omega_leggings", OmegaItem.Leggings::new);
	public static final DeferredItem<Item> OMEGA_BOOTS = register("omega_boots", OmegaItem.Boots::new);
	public static final DeferredItem<Item> RT = register("rt", RtItem::new);
	public static final DeferredItem<Item> OMEGA_BOW = register("omega_bow", OmegaBowItem::new);
	public static final DeferredItem<Item> RER = block(RileyModBlocks.RER);
	public static final DeferredItem<Item> RNVMBF = block(RileyModBlocks.RNVMBF);
	public static final DeferredItem<Item> FGGJ = block(RileyModBlocks.FGGJ);
	public static final DeferredItem<Item> HHGM = block(RileyModBlocks.HHGM);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}