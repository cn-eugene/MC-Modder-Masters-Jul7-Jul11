/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.riley.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.riley.RileyMod;

public class RileyModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, RileyMod.MODID);
	public static final DeferredHolder<Potion, Potion> FIRE = REGISTRY.register("fire", () -> new Potion("fire", new MobEffectInstance(RileyModMobEffects.ARROW, 1000, 0, false, true)));
}