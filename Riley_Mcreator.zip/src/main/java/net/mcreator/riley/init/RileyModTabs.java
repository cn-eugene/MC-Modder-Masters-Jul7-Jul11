/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.riley.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.riley.RileyMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class RileyModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RileyMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(RileyModItems.OMEGA_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(RileyModItems.OMEGA_HELMET.get());
			tabData.accept(RileyModItems.OMEGA_CHESTPLATE.get());
			tabData.accept(RileyModItems.OMEGA_LEGGINGS.get());
			tabData.accept(RileyModItems.OMEGA_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(RileyModBlocks.RER.get().asItem());
		}
	}
}