package net.mcreator.riley.item;

import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Item;
import net.minecraft.tags.TagKey;
import net.minecraft.tags.BlockTags;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

public class OmegaSwordItem extends SwordItem {
	private static final ToolMaterial TOOL_MATERIAL = new ToolMaterial(BlockTags.INCORRECT_FOR_WOODEN_TOOL, 10000, 4f, 0, 2, TagKey.create(Registries.ITEM, ResourceLocation.parse("riley:omega_sword_repair_items")));

	public OmegaSwordItem(Item.Properties properties) {
		super(TOOL_MATERIAL, 127999f, 51f, properties);
	}
}