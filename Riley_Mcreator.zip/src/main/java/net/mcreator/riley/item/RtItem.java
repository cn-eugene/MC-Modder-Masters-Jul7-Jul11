package net.mcreator.riley.item;

import net.minecraft.world.item.Item;

public class RtItem extends Item {
	public RtItem(Item.Properties properties) {
		super(properties);
	}
}