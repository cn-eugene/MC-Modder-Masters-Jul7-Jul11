package net.mcreator.sterling.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.sterling.entity.BarrelFreindEntity;
import net.mcreator.sterling.client.model.ModelMonsterBarrel;

public class BarrelFreindRenderer extends MobRenderer<BarrelFreindEntity, LivingEntityRenderState, ModelMonsterBarrel> {
	private BarrelFreindEntity entity = null;

	public BarrelFreindRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelMonsterBarrel(context.bakeLayer(ModelMonsterBarrel.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public LivingEntityRenderState createRenderState() {
		return new LivingEntityRenderState();
	}

	@Override
	public void extractRenderState(BarrelFreindEntity entity, LivingEntityRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		this.entity = entity;
	}

	@Override
	public ResourceLocation getTextureLocation(LivingEntityRenderState state) {
		return ResourceLocation.parse("sterling_:textures/entities/texture1.png");
	}
}