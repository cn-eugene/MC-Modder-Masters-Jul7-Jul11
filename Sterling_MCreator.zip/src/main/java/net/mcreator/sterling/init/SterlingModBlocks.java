/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sterling.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.sterling.block.PermafrostBlock;
import net.mcreator.sterling.block.MonsterHeadBlock;
import net.mcreator.sterling.block.LandMineBlock;
import net.mcreator.sterling.block.IceCrystalBlockBlock;
import net.mcreator.sterling.block.FrozenPlanksBlock;
import net.mcreator.sterling.block.FrozenOreBlock;
import net.mcreator.sterling.block.FrozenGrassBlock;
import net.mcreator.sterling.block.FrostbiteTNTBlock;
import net.mcreator.sterling.block.FrostWoodBlock;
import net.mcreator.sterling.SterlingMod;

import java.util.function.Function;

public class SterlingModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(SterlingMod.MODID);
	public static final DeferredBlock<Block> FROZEN_ORE = register("frozen_ore", FrozenOreBlock::new);
	public static final DeferredBlock<Block> ICE_CRYSTAL_BLOCK = register("ice_crystal_block", IceCrystalBlockBlock::new);
	public static final DeferredBlock<Block> MONSTER_HEAD = register("monster_head", MonsterHeadBlock::new);
	public static final DeferredBlock<Block> FROSTBITE_TNT = register("frostbite_tnt", FrostbiteTNTBlock::new);
	public static final DeferredBlock<Block> FROST_WOOD = register("frost_wood", FrostWoodBlock::new);
	public static final DeferredBlock<Block> PERMAFROST = register("permafrost", PermafrostBlock::new);
	public static final DeferredBlock<Block> FROZEN_GRASS = register("frozen_grass", FrozenGrassBlock::new);
	public static final DeferredBlock<Block> FROZEN_PLANKS = register("frozen_planks", FrozenPlanksBlock::new);
	public static final DeferredBlock<Block> LAND_MINE = register("land_mine", LandMineBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}