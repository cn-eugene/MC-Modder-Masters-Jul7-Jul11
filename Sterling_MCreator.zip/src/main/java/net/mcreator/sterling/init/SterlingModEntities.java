/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sterling.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.sterling.entity.FrostbitePigmanEntity;
import net.mcreator.sterling.entity.BarrelFreindEntity;
import net.mcreator.sterling.SterlingMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class SterlingModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, SterlingMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<FrostbitePigmanEntity>> FROSTBITE_PIGMAN = register("frostbite_pigman",
			EntityType.Builder.<FrostbitePigmanEntity>of(FrostbitePigmanEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.95f));
	public static final DeferredHolder<EntityType<?>, EntityType<BarrelFreindEntity>> BARREL_FREIND = register("barrel_freind",
			EntityType.Builder.<BarrelFreindEntity>of(BarrelFreindEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(ResourceKey.create(Registries.ENTITY_TYPE, ResourceLocation.fromNamespaceAndPath(SterlingMod.MODID, registryname))));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		FrostbitePigmanEntity.init(event);
		BarrelFreindEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(FROSTBITE_PIGMAN.get(), FrostbitePigmanEntity.createAttributes().build());
		event.put(BARREL_FREIND.get(), BarrelFreindEntity.createAttributes().build());
	}
}