/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sterling.init;

import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.api.distmarker.Dist;

import net.mcreator.sterling.client.renderer.FrostbitePigmanRenderer;
import net.mcreator.sterling.client.renderer.BarrelFreindRenderer;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class SterlingModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(SterlingModEntities.FROSTBITE_PIGMAN.get(), FrostbitePigmanRenderer::new);
		event.registerEntityRenderer(SterlingModEntities.BARREL_FREIND.get(), BarrelFreindRenderer::new);
	}
}