/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sterling.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.sterling.item.VineArmorItem;
import net.mcreator.sterling.item.SparkMakerItem;
import net.mcreator.sterling.item.IceCrystalItem;
import net.mcreator.sterling.item.FrostSwordItem;
import net.mcreator.sterling.item.FrostPickaxeItem;
import net.mcreator.sterling.item.FrostIngotItem;
import net.mcreator.sterling.item.FrostHoeItem;
import net.mcreator.sterling.item.FrostArmorItem;
import net.mcreator.sterling.item.ClubItem;
import net.mcreator.sterling.SterlingMod;

import java.util.function.Function;

public class SterlingModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(SterlingMod.MODID);
	public static final DeferredItem<Item> ICE_CRYSTAL = register("ice_crystal", IceCrystalItem::new);
	public static final DeferredItem<Item> FROZEN_ORE = block(SterlingModBlocks.FROZEN_ORE);
	public static final DeferredItem<Item> FROST_INGOT = register("frost_ingot", FrostIngotItem::new);
	public static final DeferredItem<Item> FROST_SWORD = register("frost_sword", FrostSwordItem::new);
	public static final DeferredItem<Item> SPARK_MAKER = register("spark_maker", SparkMakerItem::new);
	public static final DeferredItem<Item> FROST_ARMOR_HELMET = register("frost_armor_helmet", FrostArmorItem.Helmet::new);
	public static final DeferredItem<Item> FROST_ARMOR_CHESTPLATE = register("frost_armor_chestplate", FrostArmorItem.Chestplate::new);
	public static final DeferredItem<Item> FROST_ARMOR_LEGGINGS = register("frost_armor_leggings", FrostArmorItem.Leggings::new);
	public static final DeferredItem<Item> FROST_ARMOR_BOOTS = register("frost_armor_boots", FrostArmorItem.Boots::new);
	public static final DeferredItem<Item> ICE_CRYSTAL_BLOCK = block(SterlingModBlocks.ICE_CRYSTAL_BLOCK);
	public static final DeferredItem<Item> MONSTER_HEAD = block(SterlingModBlocks.MONSTER_HEAD);
	public static final DeferredItem<Item> FROSTBITE_TNT = block(SterlingModBlocks.FROSTBITE_TNT);
	public static final DeferredItem<Item> FROST_PICKAXE = register("frost_pickaxe", FrostPickaxeItem::new);
	public static final DeferredItem<Item> FROST_HOE = register("frost_hoe", FrostHoeItem::new);
	public static final DeferredItem<Item> VINE_ARMOR_HELMET = register("vine_armor_helmet", VineArmorItem.Helmet::new);
	public static final DeferredItem<Item> VINE_ARMOR_CHESTPLATE = register("vine_armor_chestplate", VineArmorItem.Chestplate::new);
	public static final DeferredItem<Item> VINE_ARMOR_LEGGINGS = register("vine_armor_leggings", VineArmorItem.Leggings::new);
	public static final DeferredItem<Item> VINE_ARMOR_BOOTS = register("vine_armor_boots", VineArmorItem.Boots::new);
	public static final DeferredItem<Item> FROSTBITE_PIGMAN_SPAWN_EGG = register("frostbite_pigman_spawn_egg", properties -> new SpawnEggItem(SterlingModEntities.FROSTBITE_PIGMAN.get(), properties));
	public static final DeferredItem<Item> CLUB = register("club", ClubItem::new);
	public static final DeferredItem<Item> BARREL_FREIND_SPAWN_EGG = register("barrel_freind_spawn_egg", properties -> new SpawnEggItem(SterlingModEntities.BARREL_FREIND.get(), properties));
	public static final DeferredItem<Item> FROST_WOOD = block(SterlingModBlocks.FROST_WOOD);
	public static final DeferredItem<Item> PERMAFROST = block(SterlingModBlocks.PERMAFROST);
	public static final DeferredItem<Item> FROZEN_GRASS = block(SterlingModBlocks.FROZEN_GRASS);
	public static final DeferredItem<Item> FROZEN_PLANKS = block(SterlingModBlocks.FROZEN_PLANKS);
	public static final DeferredItem<Item> LAND_MINE = block(SterlingModBlocks.LAND_MINE);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}