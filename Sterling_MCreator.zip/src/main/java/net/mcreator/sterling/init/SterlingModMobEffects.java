/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sterling.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.sterling.potion.ArrowEffectMobEffect;
import net.mcreator.sterling.SterlingMod;

public class SterlingModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, SterlingMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> ARROW_EFFECT = REGISTRY.register("arrow_effect", () -> new ArrowEffectMobEffect());
}