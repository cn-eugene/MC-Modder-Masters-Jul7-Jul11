/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sterling.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.alchemy.Potion;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.core.registries.Registries;

import net.mcreator.sterling.SterlingMod;

public class SterlingModPotions {
	public static final DeferredRegister<Potion> REGISTRY = DeferredRegister.create(Registries.POTION, SterlingMod.MODID);
	public static final DeferredHolder<Potion, Potion> POTION_OF_FLAMING_ARROWS = REGISTRY.register("potion_of_flaming_arrows",
			() -> new Potion("potion_of_flaming_arrows", new MobEffectInstance(SterlingModMobEffects.ARROW_EFFECT, 100, 0, false, false)));
}