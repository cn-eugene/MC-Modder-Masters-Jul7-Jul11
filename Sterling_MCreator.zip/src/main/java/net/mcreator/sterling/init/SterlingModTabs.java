/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.sterling.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.sterling.SterlingMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class SterlingModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SterlingMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(SterlingModItems.ICE_CRYSTAL.get());
			tabData.accept(SterlingModItems.FROST_INGOT.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(SterlingModBlocks.FROZEN_ORE.get().asItem());
			tabData.accept(SterlingModBlocks.ICE_CRYSTAL_BLOCK.get().asItem());
			tabData.accept(SterlingModBlocks.MONSTER_HEAD.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(SterlingModItems.FROST_SWORD.get());
			tabData.accept(SterlingModItems.FROST_ARMOR_HELMET.get());
			tabData.accept(SterlingModItems.FROST_ARMOR_CHESTPLATE.get());
			tabData.accept(SterlingModItems.FROST_ARMOR_LEGGINGS.get());
			tabData.accept(SterlingModItems.FROST_ARMOR_BOOTS.get());
			tabData.accept(SterlingModItems.VINE_ARMOR_HELMET.get());
			tabData.accept(SterlingModItems.VINE_ARMOR_CHESTPLATE.get());
			tabData.accept(SterlingModItems.VINE_ARMOR_LEGGINGS.get());
			tabData.accept(SterlingModItems.VINE_ARMOR_BOOTS.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(SterlingModItems.SPARK_MAKER.get());
			tabData.accept(SterlingModItems.FROST_PICKAXE.get());
			tabData.accept(SterlingModItems.FROST_HOE.get());
			tabData.accept(SterlingModItems.CLUB.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(SterlingModBlocks.FROSTBITE_TNT.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(SterlingModItems.FROSTBITE_PIGMAN_SPAWN_EGG.get());
			tabData.accept(SterlingModItems.BARREL_FREIND_SPAWN_EGG.get());
		}
	}
}