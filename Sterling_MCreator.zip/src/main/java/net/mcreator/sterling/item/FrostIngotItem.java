package net.mcreator.sterling.item;

import net.minecraft.world.item.Item;

public class FrostIngotItem extends Item {
	public FrostIngotItem(Item.Properties properties) {
		super(properties);
	}
}