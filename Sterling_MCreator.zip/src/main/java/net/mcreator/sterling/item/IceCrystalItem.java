package net.mcreator.sterling.item;

import net.minecraft.world.item.Item;

public class IceCrystalItem extends Item {
	public IceCrystalItem(Item.Properties properties) {
		super(properties);
	}
}