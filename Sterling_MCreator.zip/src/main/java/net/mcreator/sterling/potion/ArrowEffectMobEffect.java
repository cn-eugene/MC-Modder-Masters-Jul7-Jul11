package net.mcreator.sterling.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.sterling.procedures.ArrowEffectOnEffectActiveTickProcedure;

public class ArrowEffectMobEffect extends MobEffect {
	public ArrowEffectMobEffect() {
		super(MobEffectCategory.HARMFUL, -52429);
	}

	@Override
	public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
		return true;
	}

	@Override
	public boolean applyEffectTick(ServerLevel level, LivingEntity entity, int amplifier) {
		ArrowEffectOnEffectActiveTickProcedure.execute(level, entity);
		return super.applyEffectTick(level, entity, amplifier);
	}
}