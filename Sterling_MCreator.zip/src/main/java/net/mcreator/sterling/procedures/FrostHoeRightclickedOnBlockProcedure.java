package net.mcreator.sterling.procedures;

public class FrostHoeRightclickedOnBlockProcedure {
	public static void execute() {
	}
}