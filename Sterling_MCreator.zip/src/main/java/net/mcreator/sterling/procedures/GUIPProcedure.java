package net.mcreator.sterling.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.sterling.init.SterlingModMenus;
import net.mcreator.sterling.init.SterlingModBlocks;

public class GUIPProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof Player _player && _player.containerMenu instanceof SterlingModMenus.MenuAccessor _menu) {
			ItemStack _setstack = new ItemStack(SterlingModBlocks.MONSTER_HEAD.get()).copy();
			_setstack.setCount(1);
			_menu.getSlots().get(0).set(_setstack);
			_player.containerMenu.broadcastChanges();
		}
	}
}